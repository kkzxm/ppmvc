#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};

#end
#parse("File Header.java")
/**
 * @Author: 酷酷宅小明
 * @CreateTime: ${DATE} ${TIME}
 */
public enum ${NAME} {
}
