<template>
  <div class="${NAME}">
    
  </div>
</template>

<script>
/**
 * @Author: 酷酷宅小明
 * @CreateTime: ${DATE} ${TIME}
 */
export default {
  name: "${NAME}",
  data() {
    return {
      // 登录表单的数据绑定对象
      
    }
  },
  methods: {
    
  }
}
</script>

<style lang="less">

</style>