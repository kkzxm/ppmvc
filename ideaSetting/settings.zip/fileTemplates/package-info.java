#parse("File Header.java")
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

/**
 * @Author: 酷酷宅小明
 * @CreateTime: ${DATE} ${TIME}
 */